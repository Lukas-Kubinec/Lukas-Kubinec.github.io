/*
Design a maximum of 3 SELECT queries to retrieve interesting information from the
database (across 2. 3 or more tables), using aggregate functions e.g., Count() – Sum() –
Avg() – Min() – Max(). You may wish to demonstrate a basic query e.g., 1 table, before
undertaking the more complex ones.
You must provide in a word document -
1. Provide a plain English explanation of what the query(ies) are supposed to do.
2. Provide an explanation of how the code works for each query.
3. Provide screenshots of the returned results
4. Provide the actual MYSQL code scripts (t5query1.sql)
*/

# 1. Query 
SELECT COUNT(ArtistID) AS NumberOfArtists
FROM Artist;

# 2. Query
SELECT Stage.Name, COUNT(Performance.PerformanceID) AS NumberOfPerformances
FROM Performance
INNER JOIN Stage
ON Performance.StageID = Stage.StageID
GROUP BY Stage.Name;

# 3. Query
SELECT Attendee.FirstName, Attendee.LastName, Ticket.TicketID, TicketOption.TicketType, COUNT(AttendeePlanner.AttendeeID) AS NumberOfPlans
FROM Attendee
INNER JOIN AttendeePlanner ON AttendeePlanner.AttendeeID = Attendee.AttendeeID
INNER JOIN Ticket ON Attendee.TicketID = Ticket.TicketID
INNER JOIN TicketOption ON Ticket.TicketOptionID = TicketOption.TicketOptionID
WHERE TicketOption.TicketType = 'VIP Weekend Pass'
GROUP BY Attendee.FirstName;









