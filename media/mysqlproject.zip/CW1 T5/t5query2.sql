/*
Design a maximum of 3 queries (across 2. 3 or more tables) to demonstrate using multi-row
functions and grouping data. You may wish to demonstrate a basic query e.g., 1 table,
before undertaking the more complex ones.
You must provide in a word document -
1. Provide a plain English explanation of what the query(ies) are supposed to do.
2. Provide an explanation of how the code works for each query.
3. Provide screenshots of the returned results
4. Provide the actual MYSQL code scripts (t5query2.sql)
*/

# 1. Query
SELECT Ticket.TicketID, TicketOption.Price
FROM Ticket
RIGHT JOIN TicketOption ON Ticket.TicketOptionID = TicketOption.TicketOptionID
WHERE TicketID IS NOT NULL
GROUP BY TicketID
ORDER BY TicketOption.Price ASC;

# 2. Query
SELECT Artist.Name, COUNT(Performance.PerformanceID) AS NumberOfPerformances
FROM Artist
INNER JOIN Performance
ON Artist.ArtistID = Performance.ArtistID
GROUP BY Artist.Name
ORDER BY NumberOfPerformances ASC;

# 3. Query
SELECT Artist.Name , Stage.Name, Entertainment.StartTime
FROM Artist
RIGHT JOIN Performance ON Artist.ArtistID = Performance.ArtistID
RIGHT JOIN Entertainment ON Performance.EntertainmentID = Entertainment.EntertainmentID
RIGHT JOIN Stage ON Performance.StageID = Stage.StageID
GROUP BY Artist.Name
ORDER BY Stage.Name ASC;




