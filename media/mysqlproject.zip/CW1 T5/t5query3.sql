/*
Design a maximum of 3 queries (across 2. 3 or more tables) to demonstrate using a
subquery. You may wish to demonstrate a basic query e.g., 1 table, before undertaking the
more complex ones.
You must provide in a word document -
1. Provide a plain English explanation of what the query(ies) are supposed to do.
2. Provide an explanation of how the code works for each query.
3. Provide screenshots of the returned results
4. Provide the actual MYSQL code scripts (t5query3.sql)
*/

# 1. Query
SELECT Attendee.AttendeeID, IF(CampingOption.CampingOptionID != 'CN001', "Yes", "No") AS IsCamping
FROM Attendee
RIGHT JOIN Ticket ON Attendee.TicketID = Ticket.TicketID
RIGHT JOIN TicketOption ON Ticket.TicketOptionID = TicketOption.TicketOptionID
RIGHT JOIN CampingOption ON Ticket.CampingOptionID = CampingOption.CampingOptionID
WHERE TicketOption.Price > (SELECT AVG(Price) FROM TicketOption)
ORDER BY IsCamping DESC;

# 2. Query
SELECT Entertainment.EntertainmentID, IF(Entertainment.EntertainmentType = 'Music', "Yes", "No") AS IsMusicEvent, IF(Entertainment.EntertainmentType = 'Music', Artist.Name, NULL) AS ArtistName
FROM Entertainment
INNER JOIN Performance
ON Entertainment.EntertainmentID = Performance.EntertainmentID
INNER JOIN Artist
ON Performance.ArtistID = Artist.ArtistID
WHERE Entertainment.StartTime > '20:00:00'
GROUP BY Entertainment.EntertainmentID
ORDER BY Entertainment.EntertainmentID ASC;

# 3. Query
SELECT Entertainment.Name, Entertainment.Location,
IF(Entertainment.StartTime between '06:00:00' and '11:59:59', "X", "-") AS Morning,
IF(Entertainment.StartTime between '12:00:00' and '17:59:59', "X", "-") AS Midday,
IF(Entertainment.StartTime between '18:00:00' and '23:59:59', "X", "-") AS Evening
FROM Entertainment
WHERE Entertainment.EntertainmentID NOT LIKE 'M%';




