-- UPDATE --
-- 01. Update query
UPDATE Attendee
SET FirstName = 'Elton'
WHERE AttendeeID = 'A0001';

-- 02. Update query
SET SQL_SAFE_UPDATES = 0;
UPDATE Attendee
INNER JOIN AttendeePlanner 
ON Attendee.AttendeeID = AttendeePlanner.AttendeeID
SET Attendee.LastName = 'John';
SET SQL_SAFE_UPDATES = 1;

-- 03. Update query
SET SQL_SAFE_UPDATES = 0;
UPDATE Artist
INNER JOIN Performance ON Artist.ArtistID = Performance.ArtistID
INNER JOIN Stage ON Performance.StageID = '03'
SET Artist.Genre = 'Acoustic';
SET SQL_SAFE_UPDATES = 1;


-- DELETE --
-- 01. Delete query
DELETE FROM AttendeePlanner WHERE PlannerID = 'A0015';


-- 02. Delete query
-- Dropping foreign key
ALTER TABLE NonMusicalEntertainment DROP FOREIGN KEY NonMusicalEntertainment_ibfk_1;

-- Altering table to add correct foreign key
ALTER TABLE NonMusicalEntertainment ADD FOREIGN KEY (EntertainmentID) 
REFERENCES Entertainment(EntertainmentID) ON DELETE CASCADE ON UPDATE CASCADE;

-- Deletion of rows
DELETE NonMusicalEntertainment, Entertainment
FROM NonMusicalEntertainment
JOIN Entertainment ON NonMusicalEntertainment.EntertainmentID = Entertainment.EntertainmentID
WHERE Entertainment.EntertainmentID = 'A0001';


-- 03. Delete query
-- Dropping foreign keys
ALTER TABLE Attendee DROP FOREIGN KEY Attendee_ibfk_1;
ALTER TABLE AttendeePlanner DROP FOREIGN KEY AttendeePlanner_ibfk_1;

-- Altering table to add correct foreign key
ALTER TABLE Attendee ADD FOREIGN KEY (TicketID) 
REFERENCES Ticket(TicketID) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE AttendeePlanner ADD FOREIGN KEY (AttendeeID) 
REFERENCES Attendee(AttendeeID) ON DELETE CASCADE ON UPDATE CASCADE;

-- Deletion of rows
DELETE Ticket, Attendee, AttendeePlanner
FROM Ticket
JOIN Attendee ON Ticket.TicketID = Attendee.TicketID
JOIN AttendeePlanner ON Attendee.AttendeeID = AttendeePlanner.AttendeeID
WHERE Ticket.TicketID = 'T0001';








