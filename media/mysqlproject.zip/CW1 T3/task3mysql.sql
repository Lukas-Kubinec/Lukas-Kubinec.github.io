-- Creation of tables --
CREATE TABLE TicketOption 
(
TicketOptionID    	CHAR(5) NOT NULL,
TicketType        	VARCHAR(30) NOT NULL,
DaysCovered       	VARCHAR(30) NOT NULL,
Price             	DECIMAL(6,2) NOT NULL,
PRIMARY KEY			(TicketOptionID)
);

CREATE TABLE CampingOption (
CampingOptionID		CHAR(5) NOT NULL,
OptionType       	VARCHAR(15) NOT NULL,
Price             	DECIMAL(6,2) NOT NULL,
Amenities         	VARCHAR(255) NOT NULL,
PRIMARY KEY			(CampingOptionID)
);

CREATE TABLE Ticket
(
TicketID		CHAR(5) NOT NULL,
PurchaseDate 	DATE NOT NULL,
TicketOptionID	CHAR(5),
CampingOptionID CHAR(5),
PRIMARY KEY		(TicketID),
FOREIGN KEY		(TicketOptionID) REFERENCES TicketOption(TicketOptionID),
FOREIGN KEY		(CampingOptionID) REFERENCES CampingOption(CampingOptionID)
);

CREATE TABLE Attendee
(
AttendeeID		CHAR(5) NOT NULL,
FirstName     	VARCHAR(50) NOT NULL,
LastName      	VARCHAR(50) NOT NULL,
Email         	VARCHAR(254) NOT NULL,
ContactNumber 	VARCHAR(13) NOT NULL,
TicketID    	CHAR(5),
PRIMARY KEY		(AttendeeID),
FOREIGN KEY		(TicketID) REFERENCES Ticket(TicketID)
);

CREATE TABLE Artist (
ArtistID            	CHAR(2) NOT NULL,
Name                	VARCHAR(50) NOT NULL,
Genre               	VARCHAR(20) NOT NULL,
ProfileDescription  	VARCHAR(255) NOT NULL,
PRIMARY KEY				(ArtistID)
);

CREATE TABLE Stage (
StageID   		CHAR(2) NOT NULL,
Name      		VARCHAR(20) NOT NULL,
PRIMARY KEY		(StageID)
);

CREATE TABLE Entertainment (
EntertainmentID     	CHAR(5) NOT NULL,
EntertainmentType   	VARCHAR(10) NOT NULL,
Name                	VARCHAR(50) NOT NULL,
Location            	VARCHAR(20) NOT NULL,
Date                	VARCHAR(10) NOT NULL,
StartTime           	TIME NOT NULL,
EndTime             	TIME NOT NULL,
PRIMARY KEY				(EntertainmentID)
);

CREATE TABLE NonMusicalEntertainment (
NonMusicalEntertainmentID   CHAR(5) NOT NULL,
Type              			VARCHAR(30) NOT NULL,
EntertainmentID     		CHAR(5),
PRIMARY KEY					(NonMusicalEntertainmentID),
FOREIGN KEY					(EntertainmentID) REFERENCES Entertainment(EntertainmentID)
);

CREATE TABLE Performance (
PerformanceID     	CHAR(5) NOT NULL,
EntertainmentID     CHAR(5),
StageID   			CHAR(2),
ArtistID            CHAR(2),
PRIMARY KEY			(PerformanceID),
FOREIGN KEY			(EntertainmentID) REFERENCES Entertainment(EntertainmentID),
FOREIGN KEY			(StageID) REFERENCES Stage(StageID),
FOREIGN KEY 		(ArtistID) REFERENCES Artist(ArtistID)
);

CREATE TABLE AttendeePlanner (
PlannerID		CHAR(5) NOT NULL,
AttendeeID		CHAR(5),
EntertainmentID CHAR(5),
PRIMARY KEY		(PlannerID),
FOREIGN KEY 	(AttendeeID) REFERENCES Attendee(AttendeeID),
FOREIGN KEY		(EntertainmentID) REFERENCES Entertainment(EntertainmentID)
);


-- Populating tables --
-- Ticket Options Table
INSERT INTO TicketOption (TicketOptionID, TicketType, DaysCovered, Price)
VALUES	('DB001','Day Pass','Friday',90.00),
		('DB002','Day Pass','Saturday',100.00),
		('DB003','Day Pass','Sunday',100.00),
        ('MB001','MultiDay Pass','Friday-Saturday',150.00),
        ('MB002','MultiDay Pass','Saturday-Sunday',170.00),
        ('WB001','Weekend Pass','Friday-Saturday-Sunday',220.00),
        ('DV001','VIP Day Pass','Friday',200.00),
        ('DV002','VIP Day Pass','Saturday',220.00),
        ('DV003','VIP Day Pass','Sunday',220.00),
        ('MV001','VIP MultiDay Pass','Friday-Saturday',380.00),
        ('MV002','VIP MultiDay Pass','Saturday-Sunday',400.00),
        ('WV001','VIP Weekend Pass','Friday-Saturday-Sunday',400.00);

-- Camping Options Table
INSERT INTO CampingOption (CampingOptionID, OptionType, Price, Amenities)
VALUES	('CN001','Non',0.00,'No camping'),
		('CB001','Basic Capming',50.00,'Tent spot and basic amenities, like toilets'),
        ('CP001','Premium Capming',75.00,'Powder room, Pre-built tent and closer to the festival entrance');

-- Ticket Table
INSERT INTO Ticket (TicketID, PurchaseDate, TicketOptionID, CampingOptionID)
VALUES	('T0001', '2024:08:10', 'DB001', 'CN001'),
		('T0002', '2024:08,11', 'DB002', 'CN001'),
        ('T0003', '2024:08,13', 'MB001', 'CB001'),
        ('T0004', '2024:08,17', 'MV001', 'CP001'),
        ('T0005', '2024:08,25', 'DV003', 'CN001'),
        ('T0006', '2024:09,02', 'WV001', 'CN001'),
        ('T0007', '2024:09,09', 'DB003', 'CN001'),
        ('T0008', '2024:09,15', 'MB001', 'CB001'),
        ('T0009', '2024:09,22', 'MV002', 'CP001'),
        ('T0010', '2024:09,28', 'MV002', 'CB001'),
        ('T0011', '2024:10,01', 'DB003', 'CN001'),
        ('T0012', '2024:10,15', 'MV002', 'CB001'),
        ('T0013', '2024:10,26', 'WV001', 'CP001'),
        ('T0014', '2024:11,05', 'MV001', 'CB001'),
        ('T0015', '2024:11,11', 'DV003', 'CN001');

-- Attendee Table
INSERT INTO Attendee (AttendeeID , FirstName ,LastName , Email , ContactNumber, TicketID)
VALUES	('A0001', 'John', 'Smith', 'jSmith@mail.com', '447401123456', 'T0001'),
		('A0002', 'Paul', 'Adams', 'padams@gmai.com', '447877555147', 'T0002'),
        ('A0003', 'Jake', 'Alder', 'j.a@alders.co.uk', '447122884571', 'T0003'),
        ('A0004', 'Pauline', 'Bell', 'bellP@gov.uk', '421740107149', 'T0004'),
        ('A0005', 'Sarah', 'Bond', 'doubleoseven@bond.net', '447122884572', 'T0005'),
        ('A0006', 'Alice', 'Cooper', 'notthesinger@mymail.io', '447001072480', 'T0006'),
        ('A0007', 'Lukas', 'Curtis', 'check@hotmail.com', '447421072486', 'T0007'),
        ('A0008', 'Natalia', 'Darwin', 'darwinn@mail.com', '447401042487', 'T0008'),
        ('A0009', 'Mike', 'Green', 'green.mike@mymail.io', '447401072485', 'T0009'),
        ('A0010', 'Gareth', 'Hall', 'gar.hall@hotmail.com', '447122884579', 'T0010'),
        ('A0011', 'Phil', 'James', 'philly@mail.com', '447224987324', 'T0011'),
        ('A0012', 'Henry', 'Kelly', 'kelly.h@mymail.io', '420740107149', 'T0012'),
        ('A0013', 'Samuel', 'Jackson', 'sam.jack@hotmail.com', '447651187329', 'T0013'),
        ('A0014', 'Niamh', 'Lloyd', 'lloyd.n@hotmail.com', '447654987321', 'T0014'),
        ('A0015', 'Loraine', 'Moore', 'themoorel@mail.com', '447654987325', 'T0015');
        
-- Entertainment Table
INSERT INTO Entertainment (EntertainmentID, EntertainmentType, Name, Location, Date, StartTime, EndTime)
VALUES	('M0000', 'Music', 'Artist Performance', 'Main Stage', '2025-06-01', '12:00:00', '13:00:00'),
		('M0001', 'Music', 'Artist Performance', 'Main Stage', '2025-06-01', '15:00:00', '16:00:00'),
		('M0002', 'Music', 'Artist Performance', 'Main Stage', '2025-06-01', '18:00:00', '19:00:00'),        
        ('M0003', 'Music', 'Artist Performance', 'Main Stage', '2025-06-01', '21:00:00', '22:00:00'),
        ('M0004', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-01', '13:00:00', '14:00:00'),
        ('M0005', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-01', '16:00:00', '17:00:00'),
        ('M0006', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-01', '19:00:00', '20:00:00'),
        ('M0007', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-01', '22:00:00', '23:00:00'),
        ('M0008', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-01', '14:00:00', '15:00:00'),
        ('M0009', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-01', '17:00:00', '18:00:00'),
        ('M0010', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-01', '20:00:00', '21:00:00'),
        ('M0011', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-01', '12:30:00', '13:30:00'),
        ('M0012', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-01', '16:30:00', '17:30:00'),
        ('M0013', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-01', '19:30:00', '20:30:00'),
        ('M0014', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-01', '15:00:00', '16:00:00'),
        ('M0015', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-01', '18:00:00', '19:00:00'),
        ('M0016', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-01', '21:00:00', '22:00:00'),
        ('M0017', 'Music', 'Artist Performance', 'Main Stage', '2025-06-02', '12:00:00', '13:00:00'),
		('M0018', 'Music', 'Artist Performance', 'Main Stage', '2025-06-02', '15:00:00', '16:00:00'),
        ('M0019', 'Music', 'Artist Performance', 'Main Stage', '2025-06-02', '18:00:00', '19:00:00'),
        ('M0020', 'Music', 'Artist Performance', 'Main Stage', '2025-06-02', '21:00:00', '22:00:00'),
        ('M0021', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-02', '13:00:00', '14:00:00'),
        ('M0022', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-02', '16:00:00', '17:00:00'),
        ('M0023', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-02', '19:00:00', '20:00:00'),
        ('M0024', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-02', '22:00:00', '23:00:00'),
        ('M0025', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-02', '14:00:00', '15:00:00'),
        ('M0026', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-02', '17:00:00', '18:00:00'),
        ('M0027', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-02', '20:00:00', '21:00:00'),
        ('M0028', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-02', '13:30:00', '14:30:00'),
        ('M0029', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-02', '17:30:00', '18:30:00'),
        ('M0030', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-02', '20:30:00', '21:30:00'),
        ('M0031', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-02', '12:30:00', '13:30:00'),
        ('M0032', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-02', '16:30:00', '17:30:00'),
        ('M0033', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-02', '19:30:00', '20:30:00'),
		('M0034', 'Music', 'Artist Performance', 'Main Stage', '2025-06-03', '12:00:00', '13:00:00'),
        ('M0035', 'Music', 'Artist Performance', 'Main Stage', '2025-06-03', '15:00:00', '16:00:00'),
        ('M0036', 'Music', 'Artist Performance', 'Main Stage', '2025-06-03', '18:00:00', '19:00:00'),
        ('M0037', 'Music', 'Artist Performance', 'Main Stage', '2025-06-03', '21:00:00', '22:00:00'),
        ('M0038', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-03', '13:00:00', '14:00:00'),
        ('M0039', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-03', '16:00:00', '17:00:00'),
        ('M0040', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-03', '19:00:00', '20:00:00'),
        ('M0041', 'Music', 'Artist Performance', 'Groove Grounds', '2025-06-03', '22:00:00', '23:00:00'),
        ('M0042', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-03', '14:00:00', '15:00:00'),
        ('M0043', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-03', '17:00:00', '18:00:00'),
        ('M0044', 'Music', 'Artist Performance', 'Acoustic Corner', '2025-06-03', '20:00:00', '21:00:00'),
        ('M0045', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-03', '13:30:00', '14:30:00'),
        ('M0046', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-03', '16:30:00', '17:30:00'),
        ('M0047', 'Music', 'Artist Performance', 'Rock Riff Ridge', '2025-06-03', '19:30:00', '20:30:00'),
        ('M0048', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-03', '12:30:00', '13:30:00'),
        ('M0049', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-03', '15:30:00', '16:30:00'),
        ('M0050', 'Music', 'Artist Performance', 'Chillout Lounge', '2025-06-03', '18:30:00', '19:30:00'),
        ('S0001', 'Non-Music', 'Comedy Show', 'Comedy Tent', '2025-06-01', '18:00:00', '19:00:00'),
        ('S0002', 'Non-Music', 'Comedy Show', 'Comedy Tent', '2025-06-02', '18:00:00', '19:00:00'),
        ('S0003', 'Non-Music', 'Comedy Show', 'Comedy Tent', '2025-06-03', '18:00:00', '19:00:00'),
        ('C0001', 'Non-Music', 'Fairy Tale', 'Cinema', '2025-06-01', '16:00:00', '17:30:00'),
        ('C0002', 'Non-Music', 'Loud Hill', 'Cinema', '2025-06-01', '20:00:00', '22:00:00'),
        ('C0003', 'Non-Music', 'Shortlasting Story', 'Cinema', '2025-06-02', '16:00:00', '17:30:00'),
        ('C0004', 'Non-Music', 'Freddy', 'Cinema', '2025-06-02', '20:00:00', '22:00:00'),
        ('C0005', 'Non-Music', 'Shork 2', 'Cinema', '2025-06-03', '16:00:00', '17:30:00'),
        ('C0006', 'Non-Music', 'Slow and Curious', 'Cinema', '2025-06-03', '20:00:00', '21:30:00'),
        ('A0001', 'Non-Music', 'Modern art', 'Art Gallery', '2025-06-01', '12:00:00', '18:00:00'),
        ('A0002', 'Non-Music', 'Not so old art', 'Art Gallery', '2025-06-02', '10:00:00', '18:00:00'),
        ('A0003', 'Non-Music', 'Very old art', 'Art Gallery', '2025-06-03', '10:00:00', '18:00:00'),
        ('R0001', 'Non-Music', 'Lets be Crafty', 'Craft Market', '2025-06-01', '12:00:00', '19:00:00'),
        ('R0002', 'Non-Music', 'Your Craft?', 'Craft Market', '2025-06-02', '09:00:00', '19:00:00'),
        ('R0003', 'Non-Music', 'Mine Craft!', 'Craft Market', '2025-06-03', '09:00:00', '19:00:00'),
        ('F0001', 'Non-Music', 'Foods and Drinks', 'Food and Brew Street', '2025-06-01', '10:00:00', '23:30:00'),
        ('F0002', 'Non-Music', 'Foods and Drinks', 'Food and Brew Street', '2025-06-02', '07:00:00', '23:30:00'),
        ('F0003', 'Non-Music', 'Foods and Drinks', 'Food and Brew Street', '2025-06-03', '07:00:00', '23:30:00'),
        ('W0001', 'Non-Music', 'Lets Relax', 'Wellness Pavilion', '2025-06-01', '10:00:00', '22:30:00'),
        ('W0002', 'Non-Music', 'Lets Relax', 'Wellness Pavilion', '2025-06-02', '10:00:00', '22:30:00'),
        ('W0003', 'Non-Music', 'Lets Relax', 'Wellness Pavilion', '2025-06-03', '10:00:00', '22:30:00'),
        ('G0001', 'Non-Music', 'Lets Game!', 'Gaming Arcade', '2025-06-01', '10:00:00', '22:30:00'),
        ('G0002', 'Non-Music', 'Lets Game!', 'Gaming Arcade', '2025-06-02', '10:00:00', '22:30:00'),
        ('G0003', 'Non-Music', 'Lets Game!', 'Gaming Arcade', '2025-06-03', '10:00:00', '22:30:00');

-- Non Music Entertainment Table
INSERT INTO NonMusicalEntertainment ()
VALUES	('NM001', 'Comedy Tent', 'S0001'),
        ('NM002', 'Comedy Tent', 'S0002'),
        ('NM003', 'Comedy Tent', 'S0003'),
        ('NM004', 'Cinema', 'C0001'),
        ('NM005', 'Cinema', 'C0002'),
        ('NM006', 'Cinema', 'C0003'),
        ('NM007', 'Cinema', 'C0004'),
        ('NM008', 'Cinema', 'C0005'),
        ('NM009', 'Cinema', 'C0006'),
        ('NM010', 'Art Gallery', 'A0001'),
        ('NM011', 'Art Gallery', 'A0002'),
        ('NM012', 'Art Gallery', 'A0003'),
        ('NM013', 'Craft Market', 'R0001'),
        ('NM014', 'Craft Market', 'R0002'),
        ('NM015', 'Craft Market', 'R0003'),
        ('NM016', 'Food and Brew Street', 'F0001'),
        ('NM017', 'Food and Brew Street', 'F0002'),
        ('NM018', 'Food and Brew Street', 'F0003'),
        ('NM019', 'Wellness Pavilion', 'W0001'),
        ('NM020', 'Wellness Pavilion', 'W0002'),
        ('NM021', 'Wellness Pavilion', 'W0003'),
        ('NM022', 'Gaming Arcade', 'G0001'),
        ('NM023', 'Gaming Arcade', 'G0002'),
        ('NM024', 'Gaming Arcade', 'G0003');

-- Stage Table
INSERT INTO Stage (StageID, Name)
VALUES	('01', 'Main Stage'),
		('02', 'Groove Grounds'),
        ('03', 'Acoustic Corner'),
        ('04', 'Rock Riff Ridge'),
        ('05', 'Chillout Lounge');

-- Artist Table
INSERT INTO Artist (ArtistID, Name, Genre, ProfileDescription)
VALUES	('01', 'The Rolling Scones', 'Classic rock', 'A classic rock band known for their energetic performances.'),
		('02', 'Arctic Marmosets', 'Indie rock', 'Indie rock band famous for their cryptic lyrics.'),
        ('03', 'Flu Fighters', 'Rock', 'A rock group known for their powerful guitar riffs and dynamic stage presence.'),
        ('04', 'Lady Baba', 'Pop', 'Pop icon with a powerful voice and dramatic stage costumes.'),
        ('05', 'Red Hot Chili Poppers', 'Funk rock', 'Funk rock band that combines funky grooves with an energetic performance.'),
        ('06', 'Imagine Drag-ons', 'Metal', 'A fantasy-themed band that dresses as dragons and other mythical creatures.'),
        ('07', 'Bleetwood Mac', 'Synth pop', 'A synth-pop band with an affinity for electronic remixes of classic songs.'),
        ('08', 'Metallicalica', 'Heavy metal', 'A heavy metal band known for their thunderous sound and complex compositions.'),
        ('09', 'Adele-droid', 'Pop', 'A futuristic pop singer with digital and holographic stage elements.'),
        ('10', 'Snoop Corgi', 'Rap', 'A rapper famous for his laid-back style and animal-themed lyrics.'),
        ('11', 'Muse-ical', 'Orchestral rock', 'Known for their dramatic orchestral rock performances that tell a story.'),
        ('12', 'Nine Inch Snails', 'Industrial rock', 'A band that combines industrial rock with environmental messages.'),
        ('13', 'Queen Elizabeth', 'Rock', 'A cover band that exclusively plays hits from Queen with a regal flair.'),
        ('14', 'Gorill-az', 'Pop', 'An animated band with characters performing via augmented reality.'),
        ('15', 'The Beetles', 'Pop', 'A group known for their eco-friendly songs and activism.'),
        ('16', 'Katy Ferry', 'Pop', 'A pop artist famous for her nautical-themed performances.'),
        ('17', 'J-Zeebra', 'Hip-Hop', 'A hip-hop artist known for his sharp lyrics and striped stage costumes.'),
        ('18', 'Post Malogne', 'Electronic', 'A post-genre artist blending elements from folk, rap, and electronic music.'),
        ('19', 'The Weekend Update', 'Hip-Hop', 'A band that incorporates news and current events into their lyrics.'),
        ('20', 'Rage Against the Espresso Machine', 'Indie rock', 'Known for their energetic performances and coffee-themed merchandise.'),
        ('21', 'Marshmell-oh', 'Electronic', 'An electronic dance music artist who performs wearing a giant marshmallow head.'),
        ('22', 'The Stalking Heads', 'Rock punk', 'A band that combines punk rock with spoken word poetry.'),
        ('23', 'Kings of Lions Den', 'Biblical rock', 'Rock music with a biblical twist.'),
        ('24', 'The Kill-Joy Division', 'Post punk', 'A post-punk band with a penchant for upbeat, danceable tracks.'),
        ('25', 'Chain Smokers Anonymous', 'Electronic', 'A duo that combines electronic music with a focus on health and wellness.'),
        ('26', 'Echoes of Nowhere', 'Pop', 'A dream pop band known for ethereal soundscapes.'),
        ('27', 'Silver Strings', 'Rock', 'A modern bluegrass band with a vibrant stage presence.'),
        ('28', 'Night Howls', 'Rock', 'A garage rock band with gritty vocals and sharp guitar riffs.'),
        ('29', 'Oceanic Drift', 'Ambient', 'An ambient music group focusing on ocean- themed soundtracks.'),
        ('30', 'Skylight Serenade', 'Electronic', 'A classical crossover group blending symphonic elements with electronic beats.'),
        ('31', 'Polar Groove', 'Chillstep', 'An ice-themed performance group combining visual arts and chillstep music.'),
        ('32', 'Velvet Vortex', 'Pop', 'An alternative soul band known for its smooth rhythms and heartfelt lyrics.'),
        ('33', 'Cyber Symphony', 'Electronic', 'A techno-classical fusion ensemble that combines orchestral sounds with electronic beats.'),
        ('34', 'Lunar Tides', 'Indie pop', 'An indie pop group with catchy tunes inspired by celestial themes.'),
        ('35', 'Desert Winds', 'Jazz', 'A world music band that blends traditional Middle Eastern instruments with modern jazz influences.'),
        ('36', 'Thunder Echoes', 'Hard rock', 'A hard rock band with a penchant for loud, anthemic tracks.'),
        ('37', 'Neon Grooves', 'Disco', 'A disco revival band bringing the sparkle and dance beats of the 70s back to life.'),
        ('38', 'Twilight Serenaders', 'Folk', 'A folk duo known for their harmonious vocals and acoustic guitar.'),
        ('39', 'Digital Dreams', 'EDM', 'An EDM artist with a visual show that complements high-energy dance music with futuristic imagery.'),
        ('40', 'Harmonic Dusk', 'Jazz', 'A smooth jazz ensemble perfect for unwinding and relaxing.'),
        ('41', 'Retro Spectrum', 'Pop Rock', 'A band that revisits 80s pop rock with a modern twist.'),
        ('42', 'Pink-Flyod', 'Experimental', 'A tribute band that uses experimental sound techniques');

-- Performance Table XXXXX
INSERT INTO Performance (PerformanceID, EntertainmentID, StageID, ArtistID)
VALUES	('P0000', 'M0000', '01', '01'),
		('P0001', 'M0001', '01', '04'),
		('P0002', 'M0002', '01', '08'),
        ('P0003', 'M0003', '01', '37'),
        ('P0004', 'M0004', '02', '21'),
        ('P0005', 'M0005', '02', '11'),
        ('P0006', 'M0006', '02', '33'),
        ('P0007', 'M0007', '02', '39'),
        ('P0008', 'M0008', '03', '16'),
        ('P0009', 'M0009', '03', '30'),
        ('P0010', 'M0010', '03', '38'),
        ('P0011', 'M0011', '04', '03'),
        ('P0012', 'M0012', '04', '05'),
        ('P0013', 'M0013', '04', '36'),
        ('P0014', 'M0014', '05', '29'),
        ('P0015', 'M0015', '05', '26'),
        ('P0016', 'M0016', '05', '40'),
        ('P0017', 'M0017', '01', '14'),
        ('P0018', 'M0018', '01', '09'),
        ('P0019', 'M0019', '01', '06'),
        ('P0020', 'M0020', '01', '32'),
        ('P0021', 'M0021', '02', '17'),
        ('P0022', 'M0022', '02', '07'),
        ('P0023', 'M0023', '02', '25'),
        ('P0024', 'M0024', '02', '34'),
        ('P0025', 'M0025', '03', '27'),
        ('P0026', 'M0026', '03', '13'),
        ('P0027', 'M0027', '03', '35'),
        ('P0028', 'M0028', '04', '08'),
        ('P0029', 'M0029', '04', '22'),
        ('P0030', 'M0030', '04', '41'),
        ('P0031', 'M0031', '05', '30'),
        ('P0032', 'M0032', '05', '28'),
        ('P0033', 'M0033', '05', '42'),
        ('P0034', 'M0034', '01', '19'),
        ('P0035', 'M0035', '01', '10'),
        ('P0036', 'M0036', '01', '01'),
        ('P0037', 'M0037', '01', '41'),
        ('P0038', 'M0038', '02', '04'),
        ('P0039', 'M0039', '02', '15'),
        ('P0040', 'M0040', '02', '20'),
        ('P0041', 'M0041', '02', '39'),
        ('P0042', 'M0042', '03', '23'),
        ('P0043', 'M0043', '03', '26'),
        ('P0044', 'M0044', '03', '38'),
        ('P0045', 'M0045', '04', '03'),
        ('P0046', 'M0046', '04', '36'),
        ('P0047', 'M0047', '04', '29'),
        ('P0048', 'M0048', '05', '40'),
        ('P0049', 'M0049', '05', '02'),
        ('P0050', 'M0050', '05', '37');

-- Attendee Planner Table XXXXX
INSERT INTO AttendeePlanner (PlannerID, EntertainmentID, AttendeeID)
VALUES	('A0001', 'M0003', 'A0001'),
		('A0002', 'M0016', 'A0001'),
        ('A0003', 'M0036', 'A0014'),
        ('A0004', 'M0041', 'A0006'),
        ('A0005', 'M0026', 'A0010'),
        ('A0006', 'M0050', 'A0007'),
        ('A0007', 'M0039', 'A0005'),
        ('A0008', 'M0014', 'A0006'),
        ('A0009', 'M0027', 'A0009'),
        ('A0010', 'M0020', 'A0002'),
        ('A0011', 'M0022', 'A0002'),
        ('A0012', 'M0024', 'A0002'),
        ('A0013', 'M0026', 'A0006'),
        ('A0014', 'M0009', 'A0001'),
        ('A0015', 'M0050', 'A0011');

